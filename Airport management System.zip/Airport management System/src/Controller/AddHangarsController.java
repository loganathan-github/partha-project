package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import BO.AddHangarsBO;
import ams.Hangars;

@WebServlet("/AddHangarsController")
public class AddHangarsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 
	  String haMid=request.getParameter("managerid");
	  String haMaddress1=request.getParameter("manaddress1");
      String haMaddress2=request.getParameter("manaddress2");
      String haCity=request.getParameter("city");
      String haState=request.getParameter("state");
      String haZipcode=request.getParameter("zipcode");
      String status = "A";
      Hangars ha=new Hangars();

      ha.setHangarsManagerid(haMid);
      ha.setHangarsManageraddress1(haMaddress1);
      ha.setHangarsManageraddress2(haMaddress2);
      ha.setHangarsCity(haCity);
      ha.setHangarsState(haState);
      ha.setHangarsZipcode(haZipcode);
      ha.setStatus(status);
      AddHangarsBO ahbo=new AddHangarsBO();
      int s=ahbo.addhangars(ha);
      
	  if(s!=0)
	    {
		  RequestDispatcher rd=request.getRequestDispatcher("AdminHome.jsp");
	    	request.setAttribute("msg", "Hangar added Successfully");
	    	rd.forward(request, response);
	    }
	    else
	    {
	    	RequestDispatcher rd=request.getRequestDispatcher("AdminHome.jsp");
	    	request.setAttribute("msg", "Error in adding Hangar. Please retry adding");
	    	rd.forward(request, response);
	    }
	}
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

