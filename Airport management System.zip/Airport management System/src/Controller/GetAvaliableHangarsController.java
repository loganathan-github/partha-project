package Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import BO.HangarsBO;
import BO.PlanesBO;
import ams.Hangars;
import ams.Planes;

@WebServlet("/GetAvaliableHangarsController")
public class GetAvaliableHangarsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HangarsBO hbo=new HangarsBO();
		ArrayList<Hangars> list =hbo.availableHangars();
		PlanesBO plbo=new PlanesBO();
		//ArrayList<Planes>plList=plbo.getAllPlanes();
		//HttpSession session=request.getSession();
		if(list.size()!=0) {
			RequestDispatcher rd=request.getRequestDispatcher("availablehangars.jsp");
			//request.setAttribute("planesList",plList);
	    	request.setAttribute("hlist",list);
	    	rd.forward(request, response);
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
