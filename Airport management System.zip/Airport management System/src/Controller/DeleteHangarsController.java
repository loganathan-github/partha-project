package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import BO.HangarsBO;

@WebServlet("/DeleteHangarsController")
public class DeleteHangarsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Long haid=Long.parseLong(request.getParameter("hangarid"));
		HangarsBO habo=new HangarsBO();
		int status=habo.deleteHangars(haid);
		if(status!=0) {
			RequestDispatcher rd=request.getRequestDispatcher("DisplayHangarsController");
			rd.forward(request,response);
		}
		else {
			RequestDispatcher rd=request.getRequestDispatcher("DeleteHangars.jsp");
			request.setAttribute("msg","ENTER A VALID OR AVAILABLE HNAGER ID");
			rd.forward(request,response);
		}
	}
		}
	

