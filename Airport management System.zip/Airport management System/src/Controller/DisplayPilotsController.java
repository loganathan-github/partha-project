package Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import BO.PilotsBO;
import ams.Pilots;


@WebServlet("/DisplayPilotsController")
public class DisplayPilotsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	PilotsBO pibo=new PilotsBO();
		ArrayList<Pilots>piList=pibo.getAllPilots();
		if(piList.size()!=0) {
			RequestDispatcher rd=request.getRequestDispatcher("DisplayPilots.jsp");
			request.setAttribute("pilotsList",piList);
			rd.forward(request,response);
		}
		else {
			RequestDispatcher rd=request.getRequestDispatcher("DisplayPilots.jsp");
			request.setAttribute("pilotsList",piList);
			rd.forward(request,response);
			
		}
	}

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request,response);
	}

}
