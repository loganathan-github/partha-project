package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


import BO.ManagerLoginBO;
import ams.Manager;

@WebServlet("/ManagerLoginController")
public class ManagerLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Long mid=Long.parseLong(request.getParameter("managerid"));
		String mpassword=request.getParameter("managerpassword");
		Manager ml=new Manager();
		ml.setManagerID(mid);
		ml.setManagerPassword(mpassword);
		ManagerLoginBO mlbo=new ManagerLoginBO();
		int s=mlbo.loginManager(ml);
		System.out.println("Returned From"+s);
	    if(s!=0)
	    {
	    	String status=mlbo.checkStatus(mid);
	    	if(status.equals("Active")) {
	    		RequestDispatcher rd=request.getRequestDispatcher("ManagerHome.jsp");
	    		rd.forward(request, response);
	    	}else {
	    		RequestDispatcher rd=request.getRequestDispatcher("ManagerLogin.jsp");
	    		System.out.println("Testing");
		    	request.setAttribute("msg", "Account Not Activated Kindly Contact Admin for Activation");
		    	rd.forward(request, response);
	    	}
	    }
	    else
	    {
	    	RequestDispatcher rd=request.getRequestDispatcher("ManagerLogin.jsp");
	    	request.setAttribute("msg", "Incorrect login credentials ");
	    	rd.forward(request, response);
	    }
	}	    

	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
