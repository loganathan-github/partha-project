package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import BO.AdminRegisterBO;
import ams.Admin;

@WebServlet("/AdminRegistrationController")
public class AdminRegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Called doGet method in servlet");
		String aFname=request.getParameter("adminfname");
		String aLname=request.getParameter("adminlname");
		String aDob=request.getParameter("admindob");
		String aAge=request.getParameter("adminage");
		String aGender=request.getParameter("admingender");
		Long aContact=Long.parseLong(request.getParameter("admincontact"));
		Long aAltcontact=Long.parseLong(request.getParameter("adminaltcontact"));
		String aEmail=request.getParameter("adminemail");
		String aPassword=request.getParameter("adminpassword");
		String aAddress=request.getParameter("adminaddress");
		Admin a=new Admin();
		a.setAdminFname(aFname);
		a.setAdminLname(aLname);
		a.setAdminDob(aDob);
		a.setAdminAge(aAge);
		a.setAdminGender(aGender);
		a.setAdminContact(aContact);
		a.setAdminAltcontact(aAltcontact);
		a.setAdminEmail(aEmail);
		a.setAdminPassword(aPassword);
		a.setAdminAddress(aAddress);
		AdminRegisterBO arbo=new AdminRegisterBO();
		int s=arbo.registerAdmin(a);
	    if(s!=0)
	    {
	    	RequestDispatcher rd=request.getRequestDispatcher("AdminLogin.jsp");
	    	Long adminId=arbo.getAdminId(a.getAdminContact(),a.getAdminEmail());
	    	request.setAttribute("msg", "Admin Registered Successfully your ID is "+adminId);
	    	rd.forward(request, response);
	    	
	    }
	    else
	    {
	    	RequestDispatcher rd=request.getRequestDispatcher("AdminRegistration.jsp");
	    	request.setAttribute("msg", "Admin Not Registered");
	    	rd.forward(request, response);
	    }
	}	    

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("called dopost method in servlet");
	}

}
