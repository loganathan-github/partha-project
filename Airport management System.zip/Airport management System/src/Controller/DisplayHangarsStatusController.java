package Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import BO.HangarsBO;
import ams.Hangars;

@WebServlet("/DisplayHangarsStatusController")
public class DisplayHangarsStatusController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HangarsBO habo=new HangarsBO();
		ArrayList<Hangars>haList=habo.getAllHangars();
		if(haList.size()!=0) {
			RequestDispatcher rd=request.getRequestDispatcher("displayhangarsstatus.jsp");
			request.setAttribute("hangarsList",haList);
			rd.forward(request,response);
		}
		else {
			RequestDispatcher rd=request.getRequestDispatcher("displayhangarsstatus.jsp");
			request.setAttribute("hangarsList",haList);
			rd.forward(request,response);
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	}
}
