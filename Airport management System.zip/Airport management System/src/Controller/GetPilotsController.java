package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import BO.PilotsBO;
import ams.Pilots;


@WebServlet("/GetPilotsController")
public class GetPilotsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Long piid=Long.parseLong(request.getParameter("pilotid"));
		PilotsBO pibo = new PilotsBO();
		Pilots pi=pibo.getPilots(piid);
		if(pi!=null) {
			RequestDispatcher rd=request.getRequestDispatcher("UpdatePilots.jsp");
			request.setAttribute("pilots",pi);
			rd.forward(request,response);
		}
		
	}
}