package Controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import BO.ManagerRegisterBO;
import ams.Manager;


@WebServlet("/GetManagerApprovalByAdmin")
public class GetManagerApprovalByAdmin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ManagerRegisterBO manager = new ManagerRegisterBO();
		ArrayList<Manager> notActiveList=null;
		ArrayList<Manager> activeList=null;
		
			notActiveList = manager.getNotApprovedManagers();
			//System.out.println("Not Active Manager List"+notActiveList.size());
			activeList = manager.getApprovedManagers();
			//System.out.println("Active Manager List"+activeList.size());
			
		
			RequestDispatcher rd = request.getRequestDispatcher("managerapproval.jsp");
			request.setAttribute("managerlist1", notActiveList);
			request.setAttribute("managerlist2", activeList);
			rd.forward(request, response);
		}	
					

	

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	

}

