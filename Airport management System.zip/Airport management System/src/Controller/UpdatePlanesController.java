package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import BO.PlanesBO;
import ams.Planes;

@WebServlet("/UpdatePlanesController")
public class UpdatePlanesController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Long plid=Long.parseLong(request.getParameter("planeid"));
		Long plOid=Long.parseLong(request.getParameter("ownerid"));
		String plOfname=request.getParameter("ownerfname");
		String plOlname=request.getParameter("ownerlname");
		Long plOcontact=Long.parseLong(request.getParameter("ownercontact"));
		String plOemail=request.getParameter("owneremail");
		String plPtype=request.getParameter("ownerptype");
		Long plPcapacity=Long.parseLong(request.getParameter("ownerpcapacity"));
		Planes pl=new Planes();
		pl.setPlaneId(plid);
		pl.setPlanesOwnerid(plOid);
		pl.setPlanesOwnerfnamne(plOfname);
		pl.setPlanesOwnerlname(plOlname);
		pl.setPlanesOwnercontact(plOcontact);
		pl.setPlanesOwneremail(plOemail);
		pl.setPlanesPlanetype(plPtype);
		pl.setPlanesPlanecapacity(plPcapacity);
		PlanesBO plbo=new PlanesBO();
		int status=plbo.updatePlanes(pl);
		if(status!=0) {
			RequestDispatcher rd=request.getRequestDispatcher("DisplayPlanesController");
			rd.forward(request,response);
	}

}
}