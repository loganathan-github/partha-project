package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import BO.ManagerRegisterBO;
import ams.Manager;

@WebServlet("/ManagerRegistrationController")
public class ManagerRegistrationController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Called doGet method in servlet");
		String mFname=request.getParameter("managerfname");
		String mLname=request.getParameter("managerlname");
		String mDob=request.getParameter("managerdob");
		String mAge=request.getParameter("managerage");
		String mGender=request.getParameter("managergender");
		System.out.println("Manager Gender"+mGender);
		Long mContact=Long.parseLong(request.getParameter("managercontact"));
		Long mAltcontact=Long.parseLong(request.getParameter("manageraltcontact"));
		String mEmail=request.getParameter("manageremail");
		String mPassword=request.getParameter("managerpassword");
		String mAddress=request.getParameter("manageraddress");
		String status = "Inactive";
		Manager m=new Manager();
		m.setManagerFname(mFname);
		m.setManagerLname(mLname);
		m.setManagerDob(mDob);
		m.setManagerAge(mAge);
		m.setManagerGender(mGender);
		m.setManagerContact(mContact);
		m.setManagerAltcontact(mAltcontact);
		m.setManagerEmail(mEmail);
		m.setManagerPassword(mPassword);
		m.setManagerAddress(mAddress);
		m.setStatus(status);
		ManagerRegisterBO mrbo=new ManagerRegisterBO();
		int s=mrbo.registerManager(m);
	    if(s!=0)
	    {
	    	RequestDispatcher rd=request.getRequestDispatcher("ManagerLogin.jsp");
	    	Long managerId=mrbo.getManagerId(m.getManagerContact(),m.getManagerEmail());
	    	request.setAttribute("msg1", "Manager Registered Successfully your ID is "+managerId);
	    	rd.forward(request, response);
	    }
	    else
	    {
	    	RequestDispatcher rd=request.getRequestDispatcher("ManagerRegistration.jsp");
	    	request.setAttribute("msg", "Manager Not Registered");
	    	rd.forward(request, response);
	    }
	}	    

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("called dopost method in servlet");
	}

}
