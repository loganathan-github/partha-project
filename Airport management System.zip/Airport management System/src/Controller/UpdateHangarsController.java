package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import BO.HangarsBO;
import ams.Hangars;

@WebServlet("/UpdateHangarsController")
public class UpdateHangarsController extends HttpServlet {
	private static final long serialVersionUID = 1L;
 protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 
	Long haid=Long.parseLong(request.getParameter("hangarid"));
	String haMid=request.getParameter("managerid");
	 String haMaddress1=request.getParameter("manaddress1");
     String haMaddress2=request.getParameter("manaddress2");
     String haCity=request.getParameter("city");
     String haState=request.getParameter("state");
     String haZipcode=request.getParameter("zipcode");
     Hangars ha=new Hangars();
     ha.setHangarId(haid);
     ha.setHangarsManagerid(haMid);
     ha.setHangarsManageraddress1(haMaddress1);
     ha.setHangarsManageraddress2(haMaddress2);
     ha.setHangarsCity(haCity);
     ha.setHangarsState(haState);
     ha.setHangarsZipcode(haZipcode);
	HangarsBO habo=new HangarsBO();
	int status=habo.updateHangars(ha);
	if(status!=0) {
		RequestDispatcher rd=request.getRequestDispatcher("DisplayHangarsController");
		rd.forward(request,response);
}

}


	}


