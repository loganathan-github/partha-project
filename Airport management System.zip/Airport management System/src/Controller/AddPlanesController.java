package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import BO.AddPlanesBO;
import ams.Planes;

@WebServlet("/AddPlanesController")
public class AddPlanesController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		Long plOid=Long.parseLong(request.getParameter("ownerid"));
		String plOfname=request.getParameter("ownerfname");
		String plOlname=request.getParameter("ownerlname");
		Long plOcontact=Long.parseLong(request.getParameter("ownercontact"));
		String plOemail=request.getParameter("owneremail");
		String plPtype=request.getParameter("ownerptype");
		Long plPcapacity=Long.parseLong(request.getParameter("ownerpcapacity"));
		Planes pl=new Planes();
	
		pl.setPlanesOwnerid(plOid);
		pl.setPlanesOwnerfnamne(plOfname);
		pl.setPlanesOwnerlname(plOlname);
		pl.setPlanesOwnercontact(plOcontact);
		pl.setPlanesOwneremail(plOemail);
		pl.setPlanesPlanetype(plPtype);
		pl.setPlanesPlanecapacity(plPcapacity);
		AddPlanesBO apbo=new AddPlanesBO();
		int s=apbo.addplanes(pl);
	    if(s!=0)
	    {
	    	RequestDispatcher rd=request.getRequestDispatcher("AdminHome.jsp");
	    	request.setAttribute("msg", "Plane added Successfully");
	    	rd.forward(request, response);
	    }
	    else
	    {
	    	RequestDispatcher rd=request.getRequestDispatcher("AdminHome.jsp");
	    	request.setAttribute("msg", "Error in adding Plane. Please retry adding");
	    	rd.forward(request, response);
	    }
	    
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
