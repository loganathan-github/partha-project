package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import BO.AdminLoginBO;
import ams.Admin;

@WebServlet("/AdminLoginController")
public class AdminLoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Called doGet method in servlet");
		Long aid=Long.parseLong(request.getParameter("adminid"));
		String apassword=request.getParameter("adminpassword");
		Admin al=new Admin();
		al.setAdminID(aid);
		al.setAdminPassword(apassword);
		AdminLoginBO albo=new AdminLoginBO();
		int s=albo.loginAdmin(al);
	    if(s!=0)
	    {
	    	RequestDispatcher rd=request.getRequestDispatcher("AdminHome.jsp");    
	    	rd.forward(request, response);
	    }
	    else
	    {
	    	RequestDispatcher rd=request.getRequestDispatcher("AdminLogin.jsp");
	    	request.setAttribute("msg", "Incorrect login credentials");
	    	rd.forward(request, response);
	    }
	}	    

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
