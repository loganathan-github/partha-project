package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import BO.PlanesBO;
import ams.Planes;

@WebServlet("/GetPlanesController")
public class GetPlanesController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Long plid=Long.parseLong(request.getParameter("planeid"));
		PlanesBO plbo = new PlanesBO();
		Planes pl=plbo.getPlanes(plid);
		if(pl!=null) {
			RequestDispatcher rd=request.getRequestDispatcher("UpdatePlanes.jsp");
			request.setAttribute("planes",pl);
			rd.forward(request,response);
		}else {
			RequestDispatcher rd=request.getRequestDispatcher("GetPlanes.jsp");
			request.setAttribute("msg","Plane not found, please check the ID");
			rd.forward(request,response);
		}
	}
}


