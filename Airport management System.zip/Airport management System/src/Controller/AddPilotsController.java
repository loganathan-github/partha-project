package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import BO.AddPilotsBO;
import ams.Pilots;

@WebServlet("/AddPilotsController")
public class AddPilotsController extends HttpServlet {
	private static final long serialVersionUID = 1L;    
   protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	 
	   String piLino=request.getParameter("licensenumber");
	   String piAdd1=request.getParameter("addline1");
	   String piAdd2=request.getParameter("addline2");
	   String piCity=request.getParameter("city");
	   String piState=request.getParameter("state");
	   String piZip=request.getParameter("zipcode");
	   Long piSSN=Long.parseLong(request.getParameter("ssn"));
	   Pilots pi=new Pilots();

	   pi.setPilotsLicenseno(piLino);
	   pi.setPilotsAddress1(piAdd1);
	   pi.setPilotsAddress2(piAdd2);
	   pi.setPilotsCity(piCity);
	   pi.setPilotsState(piState);
	   pi.setPilotsZipcode(piZip);
	   pi.setPilotsSSN(piSSN);
	   AddPilotsBO apibo=new AddPilotsBO();
		int s=apibo.addpilots(pi);
	    if(s!=0)
	    {
	    	RequestDispatcher rd=request.getRequestDispatcher("AdminHome.jsp");
	    	request.setAttribute("msg", "Pilot added Successfully");
	    	rd.forward(request, response);
	    }
	    else
	    {
	    	RequestDispatcher rd=request.getRequestDispatcher("AdminHome.jsp");
	    	request.setAttribute("msg", "Error in adding Pilot. Please retry adding");
	    	rd.forward(request, response);
	    }
	    
	}

	   
	   
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
	}

}

