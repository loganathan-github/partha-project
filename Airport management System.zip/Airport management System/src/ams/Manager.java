package ams;

public class Manager {
	private Long ManagerID;
private String ManagerFname;
private String ManagerLname;
private String ManagerDob;
private String ManagerAge;
private String ManagerGender;
private Long ManagerContact;
private Long ManagerAltcontact;
private String ManagerEmail;
private String ManagerPassword;
private String ManagerAddress;
private String status;

public Manager() {
	super();	
}


public Manager(Long managerID, String managerFname, String managerLname, String managerDob, String managerAge, String managerGender,
		Long managerContact, Long managerAltcontact, String managerEmail, String managerPassword,
		String managerAddress,String status) {
	super();
	this.ManagerID = managerID;
	this.ManagerFname = managerFname;
	this.ManagerLname = managerLname;
	this.ManagerDob = managerDob;
	this.ManagerAge = managerAge;
	this.ManagerGender = managerGender;
	this.ManagerContact = managerContact;
	this.ManagerAltcontact = managerAltcontact;
	this.ManagerEmail = managerEmail;
	this.ManagerPassword = managerPassword;
	this.ManagerAddress = managerAddress;
	this.status = status;
}


public Long getManagerID() {
	return ManagerID;
}


public void setManagerID(Long managerID) {
	ManagerID = managerID;
}


public String getManagerFname() {
	return ManagerFname;
}


public void setManagerFname(String managerFname) {
	ManagerFname = managerFname;
}


public String getManagerLname() {
	return ManagerLname;
}


public void setManagerLname(String managerLname) {
	ManagerLname = managerLname;
}


public String getManagerDob() {
	return ManagerDob;
}


public void setManagerDob(String managerDob) {
	ManagerDob = managerDob;
}


public String getManagerAge() {
	return ManagerAge;
}


public void setManagerAge(String managerAge) {
	ManagerAge = managerAge;
}


public String getManagerGender() {
	return ManagerGender;
}


public void setManagerGender(String managerGender) {
	ManagerGender = managerGender;
}


public Long getManagerContact() {
	return ManagerContact;
}


public void setManagerContact(Long managerContact) {
	ManagerContact = managerContact;
}


public Long getManagerAltcontact() {
	return ManagerAltcontact;
}


public void setManagerAltcontact(Long managerAltcontact) {
	ManagerAltcontact = managerAltcontact;
}


public String getManagerEmail() {
	return ManagerEmail;
}


public void setManagerEmail(String managerEmail) {
	ManagerEmail = managerEmail;
}


public String getManagerPassword() {
	return ManagerPassword;
}


public void setManagerPassword(String managerPassword) {
	ManagerPassword = managerPassword;
}


public String getManagerAddress() {
	return ManagerAddress;
}


public void setManagerAddress(String managerAddress) {
	ManagerAddress = managerAddress;
}


public String getStatus() {
	return status;
}


public void setStatus(String status) {
	this.status = status;
}

}