package ams;

public class Pilots {
	private Long PilotId;
	private String PilotsLicenseno;
	private String PilotsAddress1;
	private String PilotsAddress2;
	private String PilotsCity;
	private String PilotsState;
	private String PilotsZipcode;
	private Long PilotsSSN;
	
	public Pilots() {
		super();	
	}

	public Pilots(Long pilotId, String pilotsLicenseno, String pilotsAddress1, String pilotsAddress2, String pilotsCity,
			String pilotsState, String pilotsZipcode, Long pilotsSSN) {
		super();
		this.PilotId = pilotId;
		this.PilotsLicenseno = pilotsLicenseno;
		this.PilotsAddress1 = pilotsAddress1;
		this.PilotsAddress2 = pilotsAddress2;
		this.PilotsCity = pilotsCity;
		this.PilotsState = pilotsState;
		this.PilotsZipcode = pilotsZipcode;
		this.PilotsSSN = pilotsSSN;
	}

	public Long getPilotId() {
		return PilotId;
	}

	public void setPilotId(Long pilotId) {
		PilotId = pilotId;
	}

	public String getPilotsLicenseno() {
		return PilotsLicenseno;
	}

	public void setPilotsLicenseno(String pilotsLicenseno) {
		PilotsLicenseno = pilotsLicenseno;
	}
	public String getPilotsAddress1() {
		return PilotsAddress1;
	}

	public void setPilotsAddress1(String pilotsAddress1) {
		PilotsAddress1 = pilotsAddress1;
	}

	public String getPilotsAddress2() {
		return PilotsAddress2;
	}

	public void setPilotsAddress2(String pilotsAddress2) {
		PilotsAddress2 = pilotsAddress2;
	}

	public String getPilotsCity() {
		return PilotsCity;
	}

	public void setPilotsCity(String pilotsCity) {
		PilotsCity = pilotsCity;
	}

	public String getPilotsState() {
		return PilotsState;
	}

	public void setPilotsState(String pilotsState) {
		PilotsState = pilotsState;
	}

	public String getPilotsZipcode() {
		return PilotsZipcode;
	}

	public void setPilotsZipcode(String pilotsZipcode) {
		PilotsZipcode = pilotsZipcode;
	}

	public Long getPilotsSSN() {
		return PilotsSSN;
	}

	public void setPilotsSSN(Long piSSN) {
		PilotsSSN = piSSN;
	}
	
}