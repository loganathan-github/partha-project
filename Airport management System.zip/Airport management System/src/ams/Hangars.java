package ams;

public class Hangars {
	private Long HangarId;
	private String HangarsManagerid;
	private String HangarsManageraddress1;
	private String HangarsManageraddress2;
	private String HangarsCity;
	private String HangarsState;
	private String HangarsZipcode;
	private String status;
	private Long planeId;
	
	public Hangars() {
		super();	
	}

	public Hangars(Long hangarId, String hangarsManagerid, String hangarsManageraddress1, String hangarsManageraddress2,
			String hangarsCity, String hangarsState, String hangarsZipcode, String status) {
		super();
		this.HangarId = hangarId;
		this.HangarsManagerid = hangarsManagerid;
		this.HangarsManageraddress1 = hangarsManageraddress1;
		this.HangarsManageraddress2 = hangarsManageraddress2;
		this.HangarsCity = hangarsCity;
		this.HangarsState = hangarsState;
		this.HangarsZipcode = hangarsZipcode;
		this.status = status;
	}

	public Long getHangarId() {
		return HangarId;
	}

	public void setHangarId(Long hangarId) {
		HangarId = hangarId;
	}

	public String getHangarsManagerid() {
		return HangarsManagerid;
	}

	public void setHangarsManagerid(String hangarsManagerid) {
		HangarsManagerid = hangarsManagerid;
	}

	public String getHangarsManageraddress1() {
		return HangarsManageraddress1;
	}

	public void setHangarsManageraddress1(String hangarsManageraddress1) {
		HangarsManageraddress1 = hangarsManageraddress1;
	}

	public String getHangarsManageraddress2() {
		return HangarsManageraddress2;
	}

	public void setHangarsManageraddress2(String hangarsManageraddress2) {
		HangarsManageraddress2 = hangarsManageraddress2;
	}

	public String getHangarsCity() {
		return HangarsCity;
	}

	public void setHangarsCity(String hangarsCity) {
		HangarsCity = hangarsCity;
	}

	public String getHangarsState() {
		return HangarsState;
	}

	public void setHangarsState(String hangarsState) {
		HangarsState = hangarsState;
	}

	public String getHangarsZipcode() {
		return HangarsZipcode;
	}

	public void setHangarsZipcode(String hangarsZipcode) {
		HangarsZipcode = hangarsZipcode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getPlaneId() {
		return planeId;
	}

	public void setPlaneId(Long planeId) {
		this.planeId = planeId;
	}
	
}
	
	