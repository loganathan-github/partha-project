package ams;

public class Planes {
	private Long PlaneId;
	private Long PlanesOwnerid;
	private String PlanesOwnerfnamne;
	private String PlanesOwnerlname;
	private Long PlanesOwnercontact;
	private String PlanesOwneremail;
	private String PlanesPlanetype;
	private Long PlanesPlanecapacity;
	
	public Planes() {
		super();	
	}

	public Planes(Long planeId, Long planesOwnerid, String planesOwnerfnamne, String planesOwnerlname, Long planesOwnercontact,
			String planesOwneremail, String planesPlanetype, Long planesPlanecapacity) {
		super();
		this.PlaneId = planeId;
		this.PlanesOwnerid = planesOwnerid;
		this.PlanesOwnerfnamne = planesOwnerfnamne;
		this.PlanesOwnerlname = planesOwnerlname;
		this.PlanesOwnercontact = planesOwnercontact;
		this.PlanesOwneremail = planesOwneremail;
		this.PlanesPlanetype = planesPlanetype;
		this.PlanesPlanecapacity = planesPlanecapacity;
	}

	public Long getPlaneId() {
		return PlaneId;
	}

	public void setPlaneId(Long planeId) {
		PlaneId = planeId;
	}

	public Long getPlanesOwnerid() {
		return PlanesOwnerid;
	}

	public void setPlanesOwnerid(Long planesOwnerid) {
		PlanesOwnerid = planesOwnerid;
	}

	public String getPlanesOwnerfnamne() {
		return PlanesOwnerfnamne;
	}

	public void setPlanesOwnerfnamne(String planesOwnerfnamne) {
		PlanesOwnerfnamne = planesOwnerfnamne;
	}

	public String getPlanesOwnerlname() {
		return PlanesOwnerlname;
	}

	public void setPlanesOwnerlname(String planesOwnerlname) {
		PlanesOwnerlname = planesOwnerlname;
	}

	public Long getPlanesOwnercontact() {
		return PlanesOwnercontact;
	}

	public void setPlanesOwnercontact(Long planesOwnercontact) {
		PlanesOwnercontact = planesOwnercontact;
	}

	public String getPlanesOwneremail() {
		return PlanesOwneremail;
	}

	public void setPlanesOwneremail(String planesOwneremail) {
		PlanesOwneremail = planesOwneremail;
	}

	public String getPlanesPlanetype() {
		return PlanesPlanetype;
	}

	public void setPlanesPlanetype(String planesPlanetype) {
		PlanesPlanetype = planesPlanetype;
	}

	public Long getPlanesPlanecapacity() {
		return PlanesPlanecapacity;
	}

	public void setPlanesPlanecapacity(Long planesPlanecapacity) {
		PlanesPlanecapacity = planesPlanecapacity;
	}
	
	

}
