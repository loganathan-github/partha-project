package ams;

public class Admin {
	private Long AdminID;
private String AdminFname;
private String AdminLname;
private String AdminDob;
private String AdminAge;
private String AdminGender;
private Long AdminContact;
private Long AdminAltcontact;
private String AdminEmail;
private String AdminPassword;
private String AdminAddress;


public Admin() {
	super();	
}


public Admin(Long adminID, String adminFname, String adminLname, String adminDob, String adminAge, String adminGender,
		Long adminContact, Long adminAltcontact, String adminEmail, String adminPassword, String adminAddress) {
	super();
	this.AdminID = adminID;
	this.AdminFname = adminFname;
	this.AdminLname = adminLname;
	this.AdminDob = adminDob;
	this.AdminAge = adminAge;
	this.AdminGender = adminGender;
	this.AdminContact = adminContact;
	this.AdminAltcontact = adminAltcontact;
	this.AdminEmail = adminEmail;
	this.AdminPassword = adminPassword;
	this.AdminAddress = adminAddress;
}


public Long getAdminID() {
	return AdminID;
}


public void setAdminID(Long adminID) {
	AdminID = adminID;
}


public String getAdminFname() {
	return AdminFname;
}


public void setAdminFname(String adminFname) {
	AdminFname = adminFname;
}


public String getAdminLname() {
	return AdminLname;
}


public void setAdminLname(String adminLname) {
	AdminLname = adminLname;
}


public String getAdminDob() {
	return AdminDob;
}


public void setAdminDob(String adminDob) {
	AdminDob = adminDob;
}


public String getAdminAge() {
	return AdminAge;
}


public void setAdminAge(String adminAge) {
	AdminAge = adminAge;
}


public String getAdminGender() {
	return AdminGender;
}


public void setAdminGender(String adminGender) {
	AdminGender = adminGender;
}


public Long getAdminContact() {
	return AdminContact;
}


public void setAdminContact(Long adminContact) {
	AdminContact = adminContact;
}


public Long getAdminAltcontact() {
	return AdminAltcontact;
}


public void setAdminAltcontact(Long adminAltcontact) {
	AdminAltcontact = adminAltcontact;
}


public String getAdminEmail() {
	return AdminEmail;
}


public void setAdminEmail(String adminEmail) {
	AdminEmail = adminEmail;
}


public String getAdminPassword() {
	return AdminPassword;
}


public void setAdminPassword(String adminPassword) {
	AdminPassword = adminPassword;
}


public String getAdminAddress() {
	return AdminAddress;
}


public void setAdminAddress(String adminAddress) {
	AdminAddress = adminAddress;
}



}


