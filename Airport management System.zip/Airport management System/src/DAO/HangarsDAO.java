package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import ams.Hangars;
public class HangarsDAO {
	int status=0;
	String url="jdbc:mysql://localhost:3306/ams";
	String username="root";
	String password="root";
	
	public int addHangars (Hangars han)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			PreparedStatement pstmt=con.prepareStatement("insert into hangars(managerid,manageraddressline1,manageraddressline2,city,state,zipcode,status) values(?,?,?,?,?,?,?)");
			pstmt.setString(1, han.getHangarsManagerid());
			pstmt.setString(2, han.getHangarsManageraddress1());
			pstmt.setString(3, han.getHangarsManageraddress2());
			pstmt.setString(4, han.getHangarsCity());
			pstmt.setString(5, han.getHangarsState());
			pstmt.setString(6, han.getHangarsZipcode());
			pstmt.setString(7, han.getStatus());
			status=pstmt.executeUpdate();
		}
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return status;
	}
	
	public ArrayList<Hangars> displayAllHangars() {
		ArrayList<Hangars>aList=new ArrayList<Hangars>();
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection(url,username,password);
				PreparedStatement pstmt=con.prepareStatement("select * from hangars");
				ResultSet rs=pstmt.executeQuery();
				while(rs.next()) {
					Hangars ha=new Hangars();
					ha.setHangarId(rs.getLong(1));
					ha.setHangarsManagerid(rs.getString(2));
					ha.setHangarsManageraddress1(rs.getString(3));
					ha.setHangarsManageraddress2(rs.getString(4));
					ha.setHangarsCity(rs.getString(5));
					ha.setHangarsState(rs.getString(6));
					ha.setHangarsZipcode(rs.getString(7));
					ha.setStatus(rs.getString(8));
					aList.add(ha);
				}
			} catch (ClassNotFoundException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return aList;
		
	}
		
		

	public Hangars getHangars(Long haid) {
		Hangars ha1=null;
		System.out.println(haid);
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			PreparedStatement pstmt=con.prepareStatement("select * from hangars where hangarid=?");
			pstmt.setLong(1,haid);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()) {
				ha1=new Hangars();
				ha1.setHangarId(rs.getLong(1));
				ha1.setHangarsManagerid(rs.getString(2));
				ha1.setHangarsManageraddress1(rs.getString(3));
				ha1.setHangarsManageraddress2(rs.getString(4));
				ha1.setHangarsCity(rs.getString(5));
				ha1.setHangarsState(rs.getString(6));
				ha1.setHangarsZipcode(rs.getString(7));					   
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return ha1;
	}

	public int hangarsDelete(Long haid) {
		int status=0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			PreparedStatement pstmt=con.prepareStatement("delete from hangars where hangarid=?");
			pstmt.setLong(1,haid);
			status=pstmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return status;
	}

	public int hangarsupdate(Hangars ha) {
		int status=0;
		String query="update hangars set managerid=?,managerAddressLine1=?,managerAddressLine2=?,city=?, state=?, zipcode=? where hangarid=?";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setString(1, ha.getHangarsManagerid());
			pstmt.setString(2, ha.getHangarsManageraddress1());
			pstmt.setString(3, ha.getHangarsManageraddress2());
			pstmt.setString(4, ha.getHangarsCity());
			pstmt.setString(5, ha.getHangarsState());
			pstmt.setString(6, ha.getHangarsZipcode());
			pstmt.setLong(7, ha.getHangarId());
			status=pstmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return status;
	}

	public ArrayList<Hangars> availableHangers() {
		ArrayList<Hangars>aList=new ArrayList<Hangars>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			PreparedStatement pstmt=con.prepareStatement("select * from hangars where status='A'");
			ResultSet rs=pstmt.executeQuery();
			while(rs.next()) {
				Hangars ha=new Hangars();
				ha.setHangarId(rs.getLong(1));
				ha.setHangarsManagerid(rs.getString(2));
				ha.setHangarsManageraddress1(rs.getString(3));
				ha.setHangarsManageraddress2(rs.getString(4));
				ha.setHangarsCity(rs.getString(5));
				ha.setHangarsState(rs.getString(6));
				ha.setHangarsZipcode(rs.getString(7));
				ha.setStatus(rs.getString(8));
				aList.add(ha);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return aList;
	
	}

	public int hangarstatusupdate(String haid,String maid,String planeId,String status) {
		int status1=0;
		System.out.println(haid+" "+maid+" "+planeId+" "+status);
		String query="update hangars set status=?,planeid=? where hangarid=?";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setString(1, status);
			pstmt.setLong(2, Long.parseLong(planeId));
			pstmt.setLong(3, Long.parseLong(haid));
			status1=pstmt.executeUpdate();
			System.out.println("DAO Status"+status1);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return status1;
	}

	
	
		


}
