package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import ams.Manager;

public class ManagerDAO {
	int status = 0;
	String url = "jdbc:mysql://localhost:3306/ams";
	String username = "root";
	String password = "root";

	public int managerRegistration(Manager ma) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt = con.prepareStatement(
					"insert into manager (firstname,lastname,dob,age,gender,contactnumber,alternatecontactnumber,emailid,password,address,status) values(?,?,?,?,?,?,?,?,?,?,?)");
			pstmt.setString(1, ma.getManagerFname());
			pstmt.setString(2, ma.getManagerLname());
			pstmt.setString(3, ma.getManagerDob());
			pstmt.setString(4, ma.getManagerAge());
			pstmt.setString(5, ma.getManagerGender());
			pstmt.setLong(6, ma.getManagerContact());
			pstmt.setLong(7, ma.getManagerAltcontact());
			pstmt.setString(8, ma.getManagerEmail());
			pstmt.setString(9, ma.getManagerPassword());
			pstmt.setString(10, ma.getManagerAddress());
			pstmt.setString(11, ma.getStatus());
			status = pstmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return status;
	}

	public Long managerRegistration(Long managerContact, String managerEmail) {
		Long myManagerId = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt = con
					.prepareStatement("select managerid from manager where contactnumber=? and emailid=?");
			pstmt.setLong(1, managerContact);
			pstmt.setString(2, managerEmail);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				myManagerId = rs.getLong(1);
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return myManagerId;

	}

	public int managerLogin(Manager manager) {
		int status = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt = con.prepareStatement("select * from manager where managerid=? and password=?");
			pstmt.setLong(1, manager.getManagerID());
			pstmt.setString(2, manager.getManagerPassword());
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				status = 1;
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}

		return status;
	}

	public ArrayList<Manager> getNotApprovedManagers() {
		ArrayList<Manager> alist = new ArrayList<Manager>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt = con.prepareStatement("select * from manager where status='Inactive'");
			ResultSet rs = pstmt.executeQuery();
			System.out.println("Manager Not Active List" + rs.getRow());
			while (rs.next()) {
				Manager m = new Manager();
				m.setManagerID(rs.getLong(1));
				m.setManagerFname(rs.getString(2));
				m.setManagerEmail(rs.getString(9));
				m.setManagerContact(rs.getLong(7));
				m.setStatus(rs.getString(12));
				alist.add(m);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return alist;
	}

	public ArrayList<Manager> getApprovedManagers() {
		ArrayList<Manager> alist1 = new ArrayList<Manager>();
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt = con.prepareStatement("select * from manager where status='Active'");
			ResultSet rs = pstmt.executeQuery();
			System.out.println("No of rows" + rs.getRow());
			while (rs.next()) {
				Manager m1 = new Manager();
				m1.setManagerID(rs.getLong(1));
				m1.setManagerFname(rs.getString(2));
				m1.setManagerEmail(rs.getString(9));
				m1.setManagerContact(rs.getLong(7));
				m1.setStatus(rs.getString(12));
				alist1.add(m1);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return alist1;
	}

	public int updateManagerStatus(String managerId) {
		int result = 0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt = con.prepareStatement("update manager set status='Active' where managerid=?");
			pstmt.setLong(1, Long.parseLong(managerId));
			result = pstmt.executeUpdate();

		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			
		}
		return result;
	}

	public String checkStatus(Long mid) {
		String status=null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection(url, username, password);
			PreparedStatement pstmt = con.prepareStatement("select status from manager where managerid=?");
			pstmt.setLong(1, mid);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				status = rs.getString(1);
			}
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return status;
	}
}
