package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import ams.Pilots;
public class PilotsDAO {
	int status=0;
	String url="jdbc:mysql://localhost:3306/ams";
	String username="root";
	String password="root";
	
	public int addPilots (Pilots pil)
	{
		
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			PreparedStatement pstmt=con.prepareStatement("insert into Pilots(licensenumber,addressline1,addressline2,city,state,zipcode,ssn) values(?,?,?,?,?,?,?)");
		
			pstmt.setString(1, pil.getPilotsLicenseno());
			pstmt.setString(2, pil.getPilotsAddress1());
			pstmt.setString(3, pil.getPilotsAddress2());
			pstmt.setString(4, pil.getPilotsCity());
			pstmt.setString(5, pil.getPilotsState());
			pstmt.setString(6, pil.getPilotsZipcode());
			pstmt.setLong(7, pil.getPilotsSSN());
			status=pstmt.executeUpdate();
		}
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return status;
	}
	public Long addpilotsID(Long Licensenumber, String ssn) {
		Long mypilotid = null;
	       try {
	              Class.forName("com.mysql.jdbc.Driver");
	              Connection con=DriverManager.getConnection(url,username,password);
	              PreparedStatement pstmt=con.prepareStatement
	                           ("select PilotId from Pilots where LicenseNumber=? and SSN=?");
	                     pstmt.setLong(1, Licensenumber);
	                     pstmt.setString(2, ssn);
	                     ResultSet rs=pstmt.executeQuery();
	                     if(rs.next()) {
	                    	 mypilotid=rs.getLong(1);
	                     }
	       }
	       catch (ClassNotFoundException | SQLException e) {
	              e.printStackTrace();
	       }
	       return mypilotid;
	       
	}

	
	
	public ArrayList<Pilots> displayAllPilots() {
		ArrayList<Pilots>aList=new ArrayList<Pilots>();{
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection(url,username,password);
				PreparedStatement pstmt=con.prepareStatement("select * from Pilots");
				ResultSet rs=pstmt.executeQuery();
				while(rs.next()) {
					Pilots pi=new Pilots();
					pi.setPilotId(rs.getLong(1));
					pi.setPilotsLicenseno(rs.getString(2));
					pi.setPilotsAddress1(rs.getString(3));
					pi.setPilotsAddress2(rs.getString(4));
					pi.setPilotsCity(rs.getString(5));
					pi.setPilotsState(rs.getString(6));
					pi.setPilotsZipcode(rs.getString(7));
					pi.setPilotsSSN(rs.getLong(8));
					aList.add(pi);
				}
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return aList;
			}
	
}
	

	public int pilotsDelete(Long piid) {
		int status=0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			PreparedStatement pstmt=con.prepareStatement("delete from Pilots where PilotId=?");
			pstmt.setLong(1,piid);
			status=pstmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return status;
	}
	
	

	public Pilots getPilots(Long piid) {
		Pilots pi1=null;
			System.out.println(piid);
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection(url,username,password);
				PreparedStatement pstmt=con.prepareStatement("select * from Pilots where PilotId=?");
				pstmt.setLong(1,piid);
				ResultSet rs=pstmt.executeQuery();
				if(rs.next()) {
					pi1=new Pilots();
					pi1.setPilotId(rs.getLong(1));
					pi1.setPilotsLicenseno(rs.getString(2));
					pi1.setPilotsAddress1(rs.getString(3));
					pi1.setPilotsAddress2(rs.getString(4));
					pi1.setPilotsCity(rs.getString(5));
					pi1.setPilotsState(rs.getString(6));
					pi1.setPilotsZipcode(rs.getString(7));
					pi1.setPilotsSSN(rs.getLong(8));
				}
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
			return pi1;
		}


	public int pilotsupdate(Pilots pi) {
		int status=0;
		String query="update Pilots set LicenseNumber=?,AddressLine1=?,AddressLine2=?,City=?, State=?, ZipCode=?, SSN=? where PilotId=?";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setString(1, pi.getPilotsLicenseno());
			pstmt.setString(2, pi.getPilotsAddress1());
			pstmt.setString(3, pi.getPilotsAddress2());
			pstmt.setString(4, pi.getPilotsCity());
			pstmt.setString(5, pi.getPilotsState());
			pstmt.setString(6, pi.getPilotsZipcode());
			pstmt.setLong(7, pi.getPilotsSSN());
			pstmt.setLong(8, pi.getPilotId());
			status=pstmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return status;
	}
	
}