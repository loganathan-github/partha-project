package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import ams.Admin;
public class AdminDAO {
	int status=0;
	String url="jdbc:mysql://localhost:3306/ams";
	String username="root";
	String password="root";
    
public int adminRegistration(Admin ad)
{
	try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection(url,username,password);
		PreparedStatement pstmt=con.prepareStatement
				("insert into admin(firstname,lastname,dob,age,gender,contactnumber,alternatecontactnumber,emailid,password,address) values(?,?,?,?,?,?,?,?,?,?)");
			pstmt.setString(1, ad.getAdminFname());
			pstmt.setString(2, ad.getAdminLname());
			pstmt.setString(3, ad.getAdminDob());
			pstmt.setString(4, ad.getAdminAge());
			pstmt.setString(5, ad.getAdminGender());
			pstmt.setLong(6, ad.getAdminContact());
			pstmt.setLong(7, ad.getAdminAltcontact());
			pstmt.setString(8, ad.getAdminEmail());
			pstmt.setString(9, ad.getAdminPassword());
			pstmt.setString(10, ad.getAdminAddress());
			status=pstmt.executeUpdate();
	}
	catch (ClassNotFoundException | SQLException e) {
		e.printStackTrace();
	}
	return status;
}

public Long adminRegistration(Long adminContact, String adminEmail) {
	Long myAdminId=null;
	try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection(url,username,password);
		PreparedStatement pstmt=con.prepareStatement
				("select adminId from admin where contactnumber=? and emailid=?");
			pstmt.setLong(1, adminContact);
			pstmt.setString(2, adminEmail);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()) {
				myAdminId=rs.getLong(1);
			}
	}
	catch (ClassNotFoundException | SQLException e) {
		e.printStackTrace();
	}
	return myAdminId;
	
}

public int adminLogin(Admin admin) {
	int status=0;
	try {
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection(url,username,password);
		PreparedStatement pstmt=con.prepareStatement
				("select * from admin where adminid=? and password=?");
		pstmt.setLong(1, admin.getAdminID());
		pstmt.setString(2, admin.getAdminPassword());
		ResultSet rs=pstmt.executeQuery();
		if(rs.next())
		{
		status=1;	
		}
	}
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	
	return status;
}
}
