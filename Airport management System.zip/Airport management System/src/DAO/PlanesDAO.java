package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import ams.Planes;
public class PlanesDAO {
	int status=0;
	String url="jdbc:mysql://localhost:3306/ams";
	String username="root";
	String password="root";
	
	public int addPlanes (Planes pla)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			PreparedStatement pstmt=con.prepareStatement("insert into planes (ownerid,ownerfirstname,ownerlastname,ownercontactnumber,owneremail,planetype,planecapacity) values(?,?,?,?,?,?,?)");
			pstmt.setLong(1, pla.getPlanesOwnerid());
			pstmt.setString(2, pla.getPlanesOwnerfnamne());
			pstmt.setString(3, pla.getPlanesOwnerlname());
			pstmt.setLong(4, pla.getPlanesOwnercontact());
			pstmt.setString(5, pla.getPlanesOwneremail());
			pstmt.setString(6, pla.getPlanesPlanetype());
			pstmt.setLong(7, pla.getPlanesPlanecapacity());
			status=pstmt.executeUpdate();
		}
		catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return status;
	}
	
	
	public ArrayList<Planes> displayAllPlanes() {
		ArrayList<Planes> aList=new ArrayList<Planes>();{
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection(url,username,password);
				PreparedStatement pstmt=con.prepareStatement("select * from planes");
				ResultSet rs=pstmt.executeQuery();
				while(rs.next()) {
					Planes pl=new Planes();
					pl.setPlaneId(rs.getLong(1));
					pl.setPlanesOwnerid(rs.getLong(2));
					pl.setPlanesOwnerfnamne(rs.getString(3));
					pl.setPlanesOwnerlname(rs.getString(4));
					pl.setPlanesOwnercontact(rs.getLong(5));
					pl.setPlanesOwneremail(rs.getString(6));
					pl.setPlanesPlanetype(rs.getString(7));
					pl.setPlanesPlanecapacity(rs.getLong(8));
					aList.add(pl);
				
				}
				} catch (ClassNotFoundException | SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return aList;
			}
	
}
	

	public int planesDelete(long plid) {
		int status=0;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			PreparedStatement pstmt=con.prepareStatement("delete from planes where planeID=?");
			pstmt.setLong(1,plid);
			status=pstmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return status;
	}
	
	

	public Planes getPlanes(Long plid) {
		Planes pl1=null;
			System.out.println(plid);
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection con=DriverManager.getConnection(url,username,password);
				PreparedStatement pstmt=con.prepareStatement("select * from planes where PlaneID=?");
				pstmt.setLong(1,plid);
				ResultSet rs=pstmt.executeQuery();
				if(rs.next()) {
					pl1=new Planes();
					pl1.setPlaneId(rs.getLong(1));
				    pl1.setPlanesOwnerid(rs.getLong(2));
					pl1.setPlanesOwnerfnamne(rs.getString(3));
					pl1.setPlanesOwnerlname(rs.getString(4));
					pl1.setPlanesOwnercontact(rs.getLong(5));
					pl1.setPlanesOwneremail(rs.getString(6));
					pl1.setPlanesPlanetype(rs.getString(7));
					pl1.setPlanesPlanecapacity(rs.getLong(8));
				}
			} catch (ClassNotFoundException | SQLException e) {
				e.printStackTrace();
			}
			return pl1;
		}


	public int planesupdate(Planes pl) {
		int status=0;
		String query="update planes set ownerID=?,ownerfirstname=?,ownerlastname=?,ownercontactnumber=?, owneremail=?, planetype=?, planecapacity=? where planeid=?";
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con=DriverManager.getConnection(url,username,password);
			PreparedStatement pstmt=con.prepareStatement(query);
			pstmt.setLong(1, pl.getPlanesOwnerid());
			pstmt.setString(2, pl.getPlanesOwnerfnamne());
			pstmt.setString(3, pl.getPlanesOwnerlname());
			pstmt.setLong(4, pl.getPlanesOwnercontact());
			pstmt.setString(5, pl.getPlanesOwneremail());
			pstmt.setString(6, pl.getPlanesPlanetype());
			pstmt.setLong(7, pl.getPlanesPlanecapacity());
			pstmt.setLong(8, pl.getPlaneId());
			status=pstmt.executeUpdate();
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return status;
	}
	
}
	

