package BO;

import java.sql.SQLException;
import java.util.ArrayList;

import DAO.ManagerDAO;
import DAO.PlanesDAO;
import ams.Manager;
import ams.Planes;

public class ManagerRegisterBO {
	ManagerDAO mdao=new ManagerDAO();
	public int registerManager (Manager manager) {
		
		int result=mdao.managerRegistration(manager);
		return result;
	}

	public Long getManagerId(Long managerContact, String managerEmail) {
		
		return mdao.managerRegistration(managerContact,managerEmail);
	}

	public ArrayList<Manager> getNotApprovedManagers()  {
		return mdao.getNotApprovedManagers();
	}
	public ArrayList<Manager> getApprovedManagers()  {
		return mdao.getApprovedManagers();
	}

	public int updateManagerStatus(String managerId) {
		
		return mdao.updateManagerStatus(managerId);
	}
	
}
	
	
