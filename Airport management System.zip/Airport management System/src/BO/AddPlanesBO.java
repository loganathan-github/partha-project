package BO;

import DAO.PlanesDAO;
import ams.Planes;

public class AddPlanesBO {
	public int addplanes (Planes planes) {
		PlanesDAO apdao=new PlanesDAO();
		int result=apdao.addPlanes(planes);
		return result;
	}

}
