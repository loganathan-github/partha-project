package BO;

import DAO.ManagerDAO;
import ams.Manager;

public class ManagerLoginBO {
	ManagerDAO adao=new ManagerDAO();
	public int loginManager (Manager manager) {
		
		int result=adao.managerLogin(manager);
		return result;
	}
	public String checkStatus(Long mid) {
		
		return adao.checkStatus(mid);
	}

	

}	