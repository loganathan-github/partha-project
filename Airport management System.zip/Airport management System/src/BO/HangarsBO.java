package BO;

import java.util.ArrayList;

import DAO.HangarsDAO;
import ams.Hangars;

public class HangarsBO {
	
	public ArrayList<Hangars> getAllHangars() {
		HangarsDAO hadao=new HangarsDAO();
		ArrayList<Hangars>list=hadao.displayAllHangars();
		return list;
	}
	
	public int deleteHangars(long haid) {
		HangarsDAO hadao=new HangarsDAO();
		int result=hadao.hangarsDelete(haid);
		return result;
	}
	
	public Hangars getHangars(long haid) {
		HangarsDAO hadao=new HangarsDAO();
	Hangars ha1=hadao.getHangars(haid);
	return ha1;
		
	}

	public int updateHangars(Hangars ha) {
		HangarsDAO hadao=new HangarsDAO();
		int result=hadao.hangarsupdate(ha);
				return result;
	}

	public ArrayList<Hangars> availableHangars() {
		HangarsDAO hadao=new HangarsDAO();
		return hadao.availableHangers();
	}

	public int updateHangarstatus(String haid,String maid,String planeId,String status) {
		HangarsDAO hadao=new HangarsDAO();
		return hadao.hangarstatusupdate(haid,maid,planeId,status);
	}

	public Hangars getHangarstatus(Long haid) {
		// TODO Auto-generated method stub
		return null;
	}
	
}
