package BO;

import java.util.ArrayList;

import DAO.PilotsDAO;
import ams.Pilots;

public class PilotsBO {
	
	public ArrayList<Pilots> getAllPilots() {
		PilotsDAO pidao=new PilotsDAO();
		ArrayList<Pilots>list=pidao.displayAllPilots();
		return list;
	}
	
	public int deletePilots(long piid) {
		PilotsDAO pidao=new PilotsDAO();
		int result=pidao.pilotsDelete(piid);
		return result;
	}
	
	public Pilots getPilots(long piid) {
	PilotsDAO pidao=new PilotsDAO();
	Pilots pi1=pidao.getPilots(piid);
	return pi1;
		
	}

	public int updatePilots(Pilots pi) {
		PilotsDAO pidao=new PilotsDAO();
		int result=pidao.pilotsupdate(pi);
				return result;
	}
	
}

