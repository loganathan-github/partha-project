package BO;

import DAO.AdminDAO;
import ams.Admin;

public class AdminLoginBO {
	AdminDAO adao=new AdminDAO();
	public int loginAdmin (Admin admin) {
		
		int result=adao.adminLogin(admin);
		return result;
	}

	

}	