package BO;

import DAO.PilotsDAO;
import ams.Pilots;

public class AddPilotsBO {
	PilotsDAO apidao=new PilotsDAO();
	public int addpilots (Pilots pilots) {
		PilotsDAO apidao=new PilotsDAO();
		int result=apidao.addPilots(pilots);
		return result;
	}
public Long getpilotId(Long Licensenumber,String ssn)
{
	return apidao.addpilotsID(Licensenumber,ssn );
	
}
}
