package BO;



import java.util.ArrayList;

import DAO.PlanesDAO;
import ams.Planes;

public class PlanesBO {
	
	public ArrayList<Planes> getAllPlanes() {
		PlanesDAO pldao=new PlanesDAO();
		ArrayList<Planes>list=pldao.displayAllPlanes();
		return list;
	}
	
	public int deletePlanes(long plid) {
		PlanesDAO pldao=new PlanesDAO();
		int result=pldao.planesDelete(plid);
		return result;
	}
	
	public Planes getPlanes(long plid) {
	PlanesDAO pldao=new PlanesDAO();
	Planes pl1=pldao.getPlanes(plid);
	return pl1;
		
	}

	public int updatePlanes(Planes pl) {
		PlanesDAO pldao=new PlanesDAO();
		int result=pldao.planesupdate(pl);
				return result;
	}
	
}
