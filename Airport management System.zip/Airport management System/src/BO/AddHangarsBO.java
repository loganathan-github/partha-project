package BO;
import DAO.HangarsDAO;
import ams.Hangars;

public class AddHangarsBO {
	public int addhangars (Hangars hangars) {
		HangarsDAO ahdao=new HangarsDAO();
		int result=ahdao.addHangars(hangars);
		return result;
	}

}
