package BO;

import DAO.AdminDAO;
import ams.Admin;

public class AdminRegisterBO {
	AdminDAO adao=new AdminDAO();
	public int registerAdmin (Admin admin) {
		
		int result=adao.adminRegistration(admin);
		return result;
	}

	public Long getAdminId(Long adminContact, String adminEmail) {
		
		return adao.adminRegistration(adminContact,adminEmail);
	}
}
